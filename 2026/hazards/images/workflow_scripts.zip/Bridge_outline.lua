-- outline_once_nonblack_to_black_on_source.lua
-- One-shot: draw a 1px BLACK outer outline around all opaque, non-black pixels.
-- • Respects selection; if none, processes the entire cel.
-- • Writes only onto transparent neighbors (won't overwrite existing outline/pixels).
-- • Auto-pads cel if outline needs space beyond current bounds.
-- • Safe write: wrapped in pcall to avoid errors if the doc is locked.

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end
  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel with an image.") end

  -- ---------- helpers ----------
  local function transparentPx(sprite)
    if sprite.colorMode == ColorMode.INDEXED then
      return sprite.transparentColor
    else
      return app.pixelColor.rgba(0,0,0,0)
    end
  end

  local function alphaOf(sprite, px)
    if not px then return 0 end
    if sprite.colorMode == ColorMode.INDEXED then
      return (px == sprite.transparentColor) and 0 or 255
    else
      return app.pixelColor.rgbaA(px)
    end
  end

  local function isExactBlackPixel(sprite, px)
    if sprite.colorMode == ColorMode.INDEXED then
      if px == sprite.transparentColor then return false end
      local c = sprite.palette:getColor(px)
      return (c.red == 0 and c.green == 0 and c.blue == 0)
    else
      return app.pixelColor.rgbaR(px) == 0
         and app.pixelColor.rgbaG(px) == 0
         and app.pixelColor.rgbaB(px) == 0
         and alphaOf(sprite, px) > 0
    end
  end

  local function blackPixel(sprite)
    if sprite.colorMode == ColorMode.INDEXED then
      local pal = sprite.palette
      local bestIdx, bestScore = 0, math.huge
      for i = 0, pal.size-1 do
        local c = pal:getColor(i)
        if c.red == 0 and c.green == 0 and c.blue == 0 then return i end
        local score = c.red*c.red + c.green*c.green + c.blue*c.blue
        if score < bestScore then bestScore, bestIdx = score, i end
      end
      return bestIdx
    else
      return app.pixelColor.rgba(0,0,0,255)
    end
  end

  local function snapshotCelToCanvas(sprite, cel)
    local img = Image(sprite.spec)      -- full-canvas (sprite coords)
    img:clear(transparentPx(sprite))
    img:drawImage(cel.image, cel.position)
    return img
  end

  -- Expand cel so all sprite-space points fit inside its image
  local function ensureCelCoversPoints(sprite, cel, pts)
    if not pts or #pts == 0 then return false end
    local cb = cel.bounds
    local minx, miny = cb.x, cb.y
    local maxx, maxy = cb.x + cb.width - 1, cb.y + cb.height - 1
    local needs = false
    for _, p in ipairs(pts) do
      if p.x < minx then minx = p.x; needs = true end
      if p.y < miny then miny = p.y; needs = true end
      if p.x > maxx then maxx = p.x; needs = true end
      if p.y > maxy then maxy = p.y; needs = true end
    end
    if not needs then return false end
    local newW = math.max(1, maxx - minx + 1)
    local newH = math.max(1, maxy - miny + 1)
    local newImg = Image(newW, newH, sprite.colorMode)
    newImg:clear(transparentPx(sprite))
    newImg:drawImage(cel.image, Point(cb.x - minx, cb.y - miny))
    cel.image = newImg
    cel.position = Point(minx, miny)
    return true
  end

  local function selectionBounds(sprite)
    local sel = sprite.selection
    if sel and (not sel.isEmpty) then
      local b = sel.bounds
      return b.x, b.y, b.x + b.width - 1, b.y + b.height - 1, true, sel
    else
      return 0, 0, sprite.width - 1, sprite.height - 1, false, nil
    end
  end

  local function inSel(sel, hasSel, sx, sy)
    return (not hasSel) or sel:contains(sx, sy)
  end

  local N4 = { {0,-1}, {1,0}, {0,1}, {-1,0} }

  -- ---------- compute once ----------
  local snap = snapshotCelToCanvas(spr, cel)
  local x0, y0, x1, y1, hasSel, sel = selectionBounds(spr)
  local W, H = spr.width, spr.height

  -- Collect transparent 4-neighbors around opaque NON-black pixels
  local toOutline = {}
  local any = false
  for sy = y0, y1 do
    for sx = x0, x1 do
      if inSel(sel, hasSel, sx, sy) then
        local px = snap:getPixel(sx, sy)
        if alphaOf(spr, px) == 255 and (not isExactBlackPixel(spr, px)) then
          for _, d in ipairs(N4) do
            local nx, ny = sx + d[1], sy + d[2]
            if nx >= 0 and ny >= 0 and nx < W and ny < H then
              if inSel(sel, hasSel, nx, ny) then
                local np = snap:getPixel(nx, ny)
                if alphaOf(spr, np) == 0 then
                  toOutline[ny * W + nx] = true
                  any = true
                end
              end
            end
          end
        end
      end
    end
  end

  if not any then return end

  -- Convert to sprite-space points
  local pts = {}
  for k,_ in pairs(toOutline) do
    local sx = k % W
    local sy = (k - sx) // W
    table.insert(pts, {x=sx, y=sy})
  end

  -- ---------- apply once (safe) ----------
  local ok = pcall(function()
    app.transaction(function()
      ensureCelCoversPoints(spr, cel, pts)
      local cb = cel.bounds
      local im = cel.image
      local iw, ih = im.width, im.height
      local BLK = blackPixel(spr)

      for _, p in ipairs(pts) do
        local ix = p.x - cb.x
        local iy = p.y - cb.y
        if ix >= 0 and iy >= 0 and ix < iw and iy < ih then
          local cur = im:getPixel(ix, iy)
          -- Only draw where it's still transparent (ignore already outlined areas)
          if alphaOf(spr, cur) == 0 then
            im:putPixel(ix, iy, BLK)
          end
        end
      end
    end)
  end)

  if not ok then
    -- Document might be locked by another command; do nothing instead of erroring.
    return
  end

  app.refresh()
end
