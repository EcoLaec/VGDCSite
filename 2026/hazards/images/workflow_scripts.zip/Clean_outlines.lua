-- clean_black_if_not_adjacent_to_opaque_nonblack.lua
-- If selection exists: operate within selection ∩ cel; else process entire cel.
-- Remove ONLY black pixels that are NOT 4-neighbor-adjacent to a non-black, opaque (α=255) pixel.

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end

  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel with an image.") end

  local sel = spr.selection
  local hasSel = (not sel.isEmpty)

  local src = cel.image:clone() -- read
  local out = src:clone()       -- write
  local cm  = spr.colorMode

  -- Encodings
  local TRANSPARENT =
    (cm == ColorMode.INDEXED)
      and spr.transparentColor
      or app.pixelColor.rgba(0, 0, 0, 0)

  -- Helpers
  local function alphaOf(px)
    if cm == ColorMode.INDEXED then
      return (px == spr.transparentColor) and 0 or 255
    else
      return app.pixelColor.rgbaA(px)
    end
  end

  local function isBlack(px)
    if cm == ColorMode.INDEXED then
      if px == spr.transparentColor then return false end
      local c = spr.palette:getColor(px)
      return (c.red == 0 and c.green == 0 and c.blue == 0)
    else
      -- treat exact (0,0,0) as black, any alpha > 0
      return (app.pixelColor.rgbaR(px) == 0
           and app.pixelColor.rgbaG(px) == 0
           and app.pixelColor.rgbaB(px) == 0
           and alphaOf(px) > 0)
    end
  end

  local function isOpaqueNonBlack(px)
    if alphaOf(px) ~= 255 then return false end
    if cm == ColorMode.INDEXED then
      if px == spr.transparentColor then return false end
      local c = spr.palette:getColor(px)
      return not (c.red == 0 and c.green == 0 and c.blue == 0)
    else
      return not (app.pixelColor.rgbaR(px) == 0
               and app.pixelColor.rgbaG(px) == 0
               and app.pixelColor.rgbaB(px) == 0)
    end
  end

  -- Bounds (sprite space)
  local celB = cel.bounds
  local work_x0, work_y0, work_x1, work_y1
  if hasSel then
    local sb = sel.bounds
    work_x0 = math.max(sb.x, celB.x)
    work_y0 = math.max(sb.y, celB.y)
    work_x1 = math.min(sb.x + sb.width,  celB.x + celB.width)  - 1
    work_y1 = math.min(sb.y + sb.height, celB.y + celB.height) - 1
    if work_x1 < work_x0 or work_y1 < work_y0 then
      return app.alert("Selection doesn’t overlap this cel.")
    end
  else
    work_x0, work_y0 = celB.x, celB.y
    work_x1 = celB.x + celB.width  - 1
    work_y1 = celB.y + celB.height - 1
  end

  local function inSelSpriteSpace(sx, sy)
    return (not hasSel) or sel:contains(sx, sy)
  end

  -- Sprite→image transform
  local cx, cy = celB.x, celB.y
  local iw, ih = src.width, src.height

  -- 4-neighbors
  local neighbors4 = {
    { 0,-1}, -- N
    { 1, 0}, -- E
    { 0, 1}, -- S
    {-1, 0}, -- W
  }

  app.transaction(function()
    for sy = work_y0, work_y1 do
      for sx = work_x0, work_x1 do
        if inSelSpriteSpace(sx, sy) then
          local ix, iy = sx - cx, sy - cy
          if ix >= 0 and iy >= 0 and ix < iw and iy < ih then
            local p = src:getPixel(ix, iy)

            -- Only consider black pixels for removal
            if isBlack(p) then
              -- Keep this black pixel iff any 4-neighbor is opaque and non-black
              local keep = false
              for _, d in ipairs(neighbors4) do
                local nx, ny = ix + d[1], iy + d[2]
                if nx >= 0 and ny >= 0 and nx < iw and ny < ih then
                  local np = src:getPixel(nx, ny)
                  if isOpaqueNonBlack(np) then
                    keep = true
                    break
                  end
                end
              end

              if not keep then
                out:putPixel(ix, iy, TRANSPARENT)
              end
            end
            -- Non-black pixels: untouched
          end
        end
      end
    end
    cel.image = out
  end)

  app.refresh()
end
