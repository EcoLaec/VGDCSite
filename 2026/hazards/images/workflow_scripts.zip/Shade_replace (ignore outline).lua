-- pick_replace_with_fg_when_next_to_bg_ignore_outlines.lua
-- Click to sample a color, then replace matching pixels with FG color
-- ONLY if:
--   • they are 4-neighbor adjacent to the current BG color, AND
--   • they are NOT outlines (NO 8-neighbor to transparency; off-image = transparent).
-- Works inside current selection (if any), else the active cel bounds.

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end

  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel with an image.") end

  local sel = spr.selection
  local cm  = spr.colorMode

  -- Work area = selection ∩ cel; or cel bounds if no selection
  local useSel = (not sel.isEmpty)
  local selB   = useSel and sel.bounds or cel.bounds
  local celB   = cel.bounds

  local x0 = math.max(selB.x, celB.x)
  local y0 = math.max(selB.y, celB.y)
  local x1 = math.min(selB.x + selB.width,  celB.x + celB.width)  - 1
  local y1 = math.min(selB.y + selB.height, celB.y + celB.height) - 1
  if x1 < x0 or y1 < y0 then
    return app.alert("Selection doesn’t overlap this cel.")
  end

  -- Sprite→image transform
  local cx, cy = celB.x, celB.y
  local iw, ih = cel.image.width, cel.image.height

  local function inSelSpriteSpace(sx, sy)
    return (not useSel) or sel:contains(sx, sy)
  end

  local neighbors4 = { {0,-1},{1,0},{0,1},{-1,0} } -- N,E,S,W
  local neighbors8 = {
    {-1,-1},{0,-1},{1,-1},
    {-1, 0},       {1, 0},
    {-1, 1},{0, 1},{1, 1}
  }

  local function currentFG()
    return (cm == ColorMode.INDEXED) and app.fgColor.index or app.fgColor.rgbaPixel
  end
  local function currentBG()
    return (cm == ColorMode.INDEXED) and app.bgColor.index or app.bgColor.rgbaPixel
  end

  local function alphaOf(px)
    if cm == ColorMode.INDEXED then
      return (px == spr.transparentColor) and 0 or 255
    else
      return app.pixelColor.rgbaA(px)
    end
  end

  -- Click → replace pass (no dialog)
  app.editor:askPoint{
    title="Click a pixel to sample (Esc to cancel)",
    onclick=function()
      local base = cel.image:clone() -- read-only snapshot
      local pt   = app.editor.spritePos
      local ix, iy = pt.x - cx, pt.y - cy
      if ix < 0 or iy < 0 or ix >= iw or iy >= ih then
        app.editor:cancel()
        return app.alert("Clicked outside the active cel.")
      end

      local pickedColor = base:getPixel(ix, iy)
      local FG_VALUE    = currentFG()
      local BG_VALUE    = currentBG()
      local out         = base:clone()

      local function touchesBG4_in_base(px, py)
        for _, d in ipairs(neighbors4) do
          local nx, ny = px + d[1], py + d[2]
          if nx >= 0 and ny >= 0 and nx < iw and ny < ih then
            if base:getPixel(nx, ny) == BG_VALUE then return true end
          end
        end
        return false
      end

      local function touchesAlpha0_8_in_base(px, py)
        for _, d in ipairs(neighbors8) do
          local nx, ny = px + d[1], py + d[2]
          if nx < 0 or ny < 0 or nx >= iw or ny >= ih then
            return true -- off-image counts as α==0
          else
            if alphaOf(base:getPixel(nx, ny)) == 0 then return true end
          end
        end
        return false
      end

      -- Replace pass: pickedColor ∧ 4-adjacent to BG ∧ NOT 8-adjacent to α==0
      for sy = y0, y1 do
        for sx = x0, x1 do
          if inSelSpriteSpace(sx, sy) then
            local px, py = sx - cx, sy - cy
            if px >= 0 and py >= 0 and px < iw and py < ih then
              local p = base:getPixel(px, py)
              if p == pickedColor and touchesBG4_in_base(px, py) and not touchesAlpha0_8_in_base(px, py) then
                out:putPixel(px, py, FG_VALUE)
              end
            end
          end
        end
      end

      app.transaction(function()
        cel.image = out
      end)

      app.editor:cancel()
      app.refresh()
    end,
    oncancel=function() end
  }
end
