-- pixel_art_aa_dual.lua
-- UI with two modes:
--   [AA]              -> "from darker pixel" antialias (user-provided behavior)
--   [AA (no angles)]  -> strict anti-45° variant (from darker pixel, corner-only)
-- If no selection is active, both modes operate over the entire cel.
-- Reads are done first; applying the result is retried if the sprite is busy
-- (e.g., while you're moving/transforming).

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end
  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel/image.") end

  local pc = app.pixelColor

  -- ---------- helpers ----------
  local function rgba_unpack(px) return pc.rgbaR(px), pc.rgbaG(px), pc.rgbaB(px), pc.rgbaA(px) end
  local function rgba_pack(r,g,b,a) return pc.rgba(r,g,b,a) end
  local function is_opaque(px) local _,_,_,a = rgba_unpack(px) return a==255 end
  local function mid(pxA, pxB)
    local r1,g1,b1 = rgba_unpack(pxA)
    local r2,g2,b2 = rgba_unpack(pxB)
    return rgba_pack(
      math.floor((r1+r2)/2 + 0.5),
      math.floor((g1+g2)/2 + 0.5),
      math.floor((b1+b2)/2 + 0.5),
      255)
  end
  local function luma(px) local r,g,b = rgba_unpack(px) return 0.299*r + 0.587*g + 0.114*b end
  local function color_delta(pxA, pxB)
    local r1,g1,b1 = rgba_unpack(pxA)
    local r2,g2,b2 = rgba_unpack(pxB)
    return math.abs(r1-r2) + math.abs(g1-g2) + math.abs(b1-b2)
  end
  local function inBounds(w,h,x,y) return x>=0 and y>=0 and x<w and y<h end
  local function make_inSel(spr, cel)
    local sel = spr.selection
    local pos = cel.position
    local processAll = sel.isEmpty
    return function(ix, iy)
      if processAll then return true end
      return sel:contains(pos.x + ix, pos.y + iy)
    end
  end

  -- status label + timer live in this state
  local dlg -- forward-declared
  local state = { retryTimer = nil }

  local function apply_with_retry(img_out)
    -- Try to apply; if the sprite is locked by another command, retry later.
    local function try_apply()
      local ok, err = pcall(function()
        app.transaction(function()
          cel.image = img_out
        end)
      end)
      if ok then
        if state.retryTimer then state.retryTimer:stop(); state.retryTimer=nil end
        if dlg then dlg:modify{ id="status", text="Applied.", visible=true } end
        app.refresh()
        return true
      else
        local msg = tostring(err or "")
        if msg:find("used by another command") or msg:find("being used by another command") then
          -- still busy; keep waiting
          return false
        else
          if state.retryTimer then state.retryTimer:stop(); state.retryTimer=nil end
          app.alert("AA failed:\n"..msg)
          if dlg then dlg:modify{ id="status", text="Error.", visible=true } end
          return true -- stop retrying on unexpected errors
        end
      end
    end

    if try_apply() then return end
    if dlg then dlg:modify{ id="status", text="Waiting for current move to finish…", visible=true } end
    state.retryTimer = Timer{
      interval = 100, -- ms
      ontick = function()
        if try_apply() then
          -- success or non-retryable error
          if state.retryTimer then state.retryTimer:stop(); state.retryTimer=nil end
        end
      end
    }
    state.retryTimer:start()
  end

  -- ---------- Mode A: AA (user-provided darker-pixel version) ----------
  local function compute_AA()
    local img  = cel.image
    local w,h  = img.width, img.height
    local out  = img:clone()
    local inSel = make_inSel(spr, cel)

    local LUMA_THR       = 16 -- neighbors must be at least this much brighter than the dark pixel
    local BRIGHT_SIM_THR = 24 -- similarity guard

    for y=0,h-1 do
      for x=0,w-1 do
        if inSel(x,y) then
          local p = img:getPixel(x,y)
          if is_opaque(p) then
            local Lp = luma(p)

            local function get_if_ok(x0,y0)
              if not (inBounds(w,h,x0,y0) and inSel(x0,y0)) then return nil end
              local q = img:getPixel(x0,y0)
              if not is_opaque(q) then return nil end
              return q
            end

            local npx = get_if_ok(x, y-1)
            local spx = get_if_ok(x, y+1)
            local wpx = get_if_ok(x-1,y)
            local epx = get_if_ok(x+1,y)

            local placed = false
            local function try_L(dxA, dyA, dxB, dyB, dxd, dyd, Apx, Bpx)
              if placed or not (Apx and Bpx) then return end
              local La, Lb = luma(Apx), luma(Bpx)
              if (La - Lp) < LUMA_THR or (Lb - Lp) < LUMA_THR then return end
              if color_delta(Apx, Bpx) > BRIGHT_SIM_THR then return end
              local dx,dy = dxd, dyd
              if not (inBounds(w,h,dx,dy) and inSel(dx,dy)) then return end
              local dpx = img:getPixel(dx,dy)
              if not is_opaque(dpx) then return end
              if (luma(dpx) - Lp) < LUMA_THR then return end

              local avgBright = rgba_pack(
                math.floor((pc.rgbaR(Apx) + pc.rgbaR(Bpx))/2 + 0.5),
                math.floor((pc.rgbaG(Apx) + pc.rgbaG(Bpx))/2 + 0.5),
                math.floor((pc.rgbaB(Apx) + pc.rgbaB(Bpx))/2 + 0.5),
                255)
              out:putPixel(x,y, mid(p, avgBright))
              placed = true
            end

            -- NW: W & N with diag (x-1,y-1)
            if wpx and npx then try_L(-1,0, 0,-1, x-1,y-1, wpx, npx) end
            -- NE: E & N with diag (x+1,y-1)
            if not placed and epx and npx then try_L( 1,0, 0,-1, x+1,y-1, epx, npx) end
            -- SW: W & S with diag (x-1,y+1)
            if not placed and wpx and spx then try_L(-1,0, 0, 1, x-1,y+1, wpx, spx) end
            -- SE: E & S with diag (x+1,y+1)
            if not placed and epx and spx then try_L( 1,0, 0, 1, x+1,y+1, epx, spx) end
          end
        end
      end
    end
    return out
  end

  -- ---------- Mode B: AA (no angles) – stricter, diagonal-proof ----------
  local function compute_AA_no_angles()
    local img  = cel.image
    local w,h  = img.width, img.height
    local out  = img:clone()
    local inSel = make_inSel(spr, cel)

    local BRIGHT_THR  = 24 -- neighbor must be at least this much brighter than P
    local DARKISH_THR = 8  -- neighbor within this of P's luma counts as dark-ish
    local BR_SIM_THR  = 24 -- bright pair similarity guard

    local function is_bright_vs(q, Lp) return q and (luma(q) - Lp) >= BRIGHT_THR end
    local function is_darkish_vs(q, Lp) return q and (luma(q) - Lp) <= DARKISH_THR end

    for y=0,h-1 do
      for x=0,w-1 do
        if inSel(x,y) then
          local P = img:getPixel(x,y)
          if is_opaque(P) then
            local Lp = luma(P)
            local function get_if_ok(x0,y0)
              if not (inBounds(w,h,x0,y0) and inSel(x0,y0)) then return nil end
              local q = img:getPixel(x0,y0)
              if not is_opaque(q) then return nil end
              return q
            end

            local N,S,W,E = get_if_ok(x, y-1), get_if_ok(x, y+1), get_if_ok(x-1, y), get_if_ok(x+1, y)
            local NW,NE,SW,SE = get_if_ok(x-1,y-1), get_if_ok(x+1,y-1), get_if_ok(x-1,y+1), get_if_ok(x+1,y+1)

            -- 45° diagonal veto (opposite diagonals both dark-ish => skip)
            if not ( (is_darkish_vs(NW, Lp) and is_darkish_vs(SE, Lp)) or
                     (is_darkish_vs(NE, Lp) and is_darkish_vs(SW, Lp)) ) then

              local placed = false
              local function try_pair(A, B, Dpx, other1, other2)
                if placed or not (A and B and Dpx) then return end
                if not (is_bright_vs(A, Lp) and is_bright_vs(B, Lp) and is_bright_vs(Dpx, Lp)) then return end
                if color_delta(A,B) > BR_SIM_THR then return end
                if not (is_darkish_vs(other1, Lp) or is_darkish_vs(other2, Lp)) then return end

                local avgBright = rgba_pack(
                  math.floor((pc.rgbaR(A) + pc.rgbaR(B))/2 + 0.5),
                  math.floor((pc.rgbaG(A) + pc.rgbaG(B))/2 + 0.5),
                  math.floor((pc.rgbaB(A) + pc.rgbaB(B))/2 + 0.5),
                  255)
                out:putPixel(x,y, mid(P, avgBright))
                placed = true
              end

              -- Four L configurations, demanding the "other" orthogonal be dark-ish to avoid 45°
              try_pair(N, E, NE, S, W)
              if not placed then try_pair(E, S, SE, N, W) end
              if not placed then try_pair(S, W, SW, N, E) end
              if not placed then try_pair(W, N, NW, E, S) end
            end
          end
        end
      end
    end
    return out
  end

  -- ---------- UI ----------
  dlg = Dialog{ title = "Pixel AA" }
  dlg:button{
    id="aa",
    text="AA",
    onclick=function()
      dlg:modify{ id="status", text="Computing…", visible=true }
      local out = compute_AA()
      apply_with_retry(out)
    end
  }
  dlg:button{
    id="aa_no_angles",
    text="AA (no angles)",
    onclick=function()
      dlg:modify{ id="status", text="Computing…", visible=true }
      local out = compute_AA_no_angles()
      apply_with_retry(out)
    end
  }
  dlg:label{ id="status", text="", visible=false }
  dlg:button{
    id="close",
    text="Close",
    onclick=function()
      if state.retryTimer then state.retryTimer:stop(); state.retryTimer=nil end
      dlg:close()
    end
  }
  dlg:show{ wait=false }
end
