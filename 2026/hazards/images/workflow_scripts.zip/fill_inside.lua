-- fill_interior_or_click_fill_samecolor_keep_outline.lua
-- Behavior:
-- • If a selection exists: fill interior (keep α==0 outline) within selection (unchanged).
-- • If no selection: ask for a click; 4-connected flood of the clicked pixel's exact color,
--   then fill ONLY the interior pixels of that region (keep α==0 outline).

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end

  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel with an image.") end

  local cm  = spr.colorMode
  local sel = spr.selection

  local src = cel.image:clone() -- read snapshot
  local out = src:clone()       -- write target

  local function FG_WRITE()
    if cm == ColorMode.INDEXED then
      return app.fgColor.index
    else
      local c = app.fgColor
      return app.pixelColor.rgba(c.red, c.green, c.blue, 255)
    end
  end

  local function alphaOf(px)
    if cm == ColorMode.INDEXED then
      return (px == spr.transparentColor) and 0 or 255
    else
      return app.pixelColor.rgbaA(px)
    end
  end

  local function pixelEq(a, b) return a == b end

  -- Sprite/cel geometry
  local celB = cel.bounds
  local cx, cy = celB.x, celB.y
  local iw, ih = src.width, src.height
  local function inImg(ix, iy) return ix >= 0 and iy >= 0 and ix < iw and iy < ih end

  local N4 = { {0,-1}, {1,0}, {0,1}, {-1,0} }

  -- ---------- Branch 1: Selection exists → original interior fill ----------
  if sel and (not sel.isEmpty) then
    local sb = sel.bounds
    local x0 = math.max(sb.x, celB.x)
    local y0 = math.max(sb.y, celB.y)
    local x1 = math.min(sb.x + sb.width,  celB.x + celB.width)  - 1
    local y1 = math.min(sb.y + sb.height, celB.y + celB.height) - 1
    if x1 < x0 or y1 < y0 then
      return app.alert("Selection doesn’t overlap this cel.")
    end

    local function inSelSpriteSpace(sx, sy) return sel:contains(sx, sy) end

    app.transaction(function()
      local FG = FG_WRITE()
      for sy = y0, y1 do
        for sx = x0, x1 do
          if inSelSpriteSpace(sx, sy) then
            local ix, iy = sx - cx, sy - cy
            if inImg(ix, iy) then
              local p = src:getPixel(ix, iy)
              if alphaOf(p) == 255 then
                -- Keep outline if any 4-neighbor is α==0 (off-image counts as α==0)
                local touchesZero = false
                for _, d in ipairs(N4) do
                  local nx, ny = ix + d[1], iy + d[2]
                  if not inImg(nx, ny) then touchesZero = true; break end
                  if alphaOf(src:getPixel(nx, ny)) == 0 then touchesZero = true; break end
                end
                if not touchesZero then
                  out:putPixel(ix, iy, FG)
                end
              end
            end
          end
        end
      end
      cel.image = out
    end)
    app.refresh()
    return
  end

  -- ---------- Branch 2: No selection → click-to-fill (same color, keep outline) ----------
  app.editor:askPoint{
    title = "Click a pixel to fill its same-color region's interior (Esc to cancel)",
    onclick = function()
      local pt = app.editor.spritePos
      local ix, iy = pt.x - cx, pt.y - cy
      if not inImg(ix, iy) then
        app.editor:cancel()
        return app.alert("Clicked outside the active cel.")
      end

      local seed = src:getPixel(ix, iy)
      local FG   = FG_WRITE()

      -- BFS gather: 4-connected pixels exactly matching 'seed'
      local visited = {}
      local function key(x, y) return y * iw + x end
      local qx, qy = {}, {}
      local qh, qt = 1, 1
      qx[1], qy[1] = ix, iy
      visited[key(ix, iy)] = true

      local region = {} -- store region pixels for a second pass
      while qh <= qt do
        local x, y = qx[qh], qy[qh]; qh = qh + 1
        region[#region+1] = {x=x, y=y}
        for _, d in ipairs(N4) do
          local nx, ny = x + d[1], y + d[2]
          if inImg(nx, ny) then
            local k = key(nx, ny)
            if not visited[k] and pixelEq(src:getPixel(nx, ny), seed) then
              visited[k] = true
              qt = qt + 1
              qx[qt], qy[qt] = nx, ny
            end
          end
        end
      end

      -- Second pass: fill ONLY interior pixels of the region (keep outline touching α==0)
      app.transaction(function()
        for _, pt2 in ipairs(region) do
          local x, y = pt2.x, pt2.y
          -- Outline test (same rule as selection): any N/E/S/W neighbor α==0 or off-image
          local touchesZero = false
          for _, d in ipairs(N4) do
            local nx, ny = x + d[1], y + d[2]
            if not inImg(nx, ny) then touchesZero = true; break end
            if alphaOf(src:getPixel(nx, ny)) == 0 then touchesZero = true; break end
          end
          if not touchesZero then
            out:putPixel(x, y, FG)
          end
          -- else: on the outer edge -> keep original (do nothing)
        end
        cel.image = out
      end)

      app.editor:cancel()
      app.refresh()
    end,
    oncancel = function() end
  }
end
