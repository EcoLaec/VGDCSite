-- soften_corners.lua
-- Paint a user-specified percentage of each stair-step arm from both ends (corner -> next corner) with Blend Color if it ends in a corner, leaving a gap.
-- For open-ended arms, paint the specified percentage from the start.
-- If percentage = 0, clamp to 1 pixel per end (two-corner arms) or 1 pixel (open-ended arms).
-- Fill single-pixel corners with at least 3 orthogonal Color 2 (or Color 1 if Invert) neighbors with Blend Color.
-- Corner = Color 1 (or Color 2 if Invert) pixel with exactly two orthogonal Color 2 (or Color 1) neighbors (N+E, E+S, S+W, W+N).
-- When Color 1 == Color 2 and Invert is true, draw on the adjacent non-Color 1 pixels that are corners or part of arms, blending with Color 1.
-- Only draw on pixels matching the target color; mask checks ignore selection; selection ONLY controls where we write.
-- If Color 1 and Color 2 are the same, blend the drawing surface color (Color 1 or non-Color 1 if Invert) with the adjacent mask color, with darker color at Auto Ratio = 0 and brighter at 100.
-- Modal dialog with Color 1/Color 2/Invert/Ignore Corners/Auto blend/Blend Color fields, Length slider, Auto Ratio slider, and Saturation slider, all changes as one undo action.
-- Preview updates for all controls (except during eyedropping) and at dialog closure.
-- Ignore Corners: When checked, skip 1-pixel stair-step arms.
-- Auto Blend: When Color 1 == Color 2, blend the drawing surface color with the adjacent mask color (darker at 0, brighter at 100); otherwise, blend darker color (0) to brighter color (100).
-- Auto Ratio: Slider (0-100) controls blend ratio: 0 = darker color (or Color 1 if not Auto Blend), 100 = brighter color (or adjacent color/Color 2), 50 = 50/50 blend.
-- Saturation: Slider (0-100) adjusts the saturation of the resulting color after blending: 0 = grayscale, 50 = unchanged, 100 = fully saturated.

do
  local spr = app.activeSprite
  if not spr then return app.alert("No active sprite.") end
  local cel = app.activeCel
  if not cel or not cel.image then return app.alert("No active cel/image.") end

  -- Store a copy of the original image to avoid accessing deleted ImageObj
  local originalImage = cel.image:clone()
  local w, h = originalImage.width, originalImage.height

  local pc = app.pixelColor
  local cm = spr.colorMode
  local sel = spr.selection
  local pos = cel.position
  local processAll = sel.isEmpty

  -- Blend Color/Color 1/Color 2 as pixels in sprite space (globals for dialog callbacks)
  local FGpix_raw
  local c1_R, c1_G, c1_B, c2_R, c2_G, c2_B
  local target_R, target_G, target_B, mask_R, mask_G, mask_B
  local dark_R, dark_G, dark_B, bright_R, bright_G, bright_B

  -- Function to calculate luminance for brightness comparison
  local function luminance(r, g, b)
    return 0.299 * r + 0.587 * g + 0.114 * b
  end

  -- Function to convert RGB to HSV
  local function rgbToHsv(r, g, b)
    r, g, b = r / 255, g / 255, b / 255
    local max, min = math.max(r, g, b), math.min(r, g, b)
    local h, s, v = 0, 0, max
    local d = max - min
    if max == 0 then
      s = 0
    else
      s = d / max
    end
    if max == min then
      h = 0 -- undefined, but set to 0
    else
      if max == r then
        h = (g - b) / d + (g < b and 6 or 0)
      elseif max == g then
        h = (b - r) / d + 2
      else
        h = (r - g) / d + 4
      end
      h = h / 6
    end
    return h, s, v
  end

  -- Function to convert HSV to RGB
  local function hsvToRgb(h, s, v)
    local r, g, b
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    else r, g, b = v, p, q end
    return math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5)
  end

  -- Adjust saturation of a color
  local function adjustSaturation(r, g, b, saturation)
    local h, s, v = rgbToHsv(r, g, b)
    local sat = saturation / 100 -- Convert percentage to 0-1 range
    local new_s
    if sat <= 0.5 then
      -- From 0 to 50: interpolate from 0 (grayscale) to original saturation
      new_s = s * (sat / 0.5)
    else
      -- From 50 to 100: interpolate from original saturation to 1 (fully saturated)
      new_s = s + (1 - s) * ((sat - 0.5) / 0.5)
    end
    new_s = math.max(0, math.min(1, new_s)) -- Clamp to [0,1]
    return hsvToRgb(h, new_s, v)
  end

  local function updateColors(blendColor, color1, color2, invert, autoBlend, autoRatio)
    -- Update RGB components for Color 1 and Color 2
    c1_R, c1_G, c1_B =
      pc.rgbaR(pc.rgba(color1.red, color1.green, color1.blue, 255)),
      pc.rgbaG(pc.rgba(color1.red, color1.green, color1.blue, 255)),
      pc.rgbaB(pc.rgba(color1.red, color1.green, color1.blue, 255))
    c2_R, c2_G, c2_B =
      pc.rgbaR(pc.rgba(color2.red, color2.green, color2.blue, 255)),
      pc.rgbaG(pc.rgba(color2.red, color2.green, color2.blue, 255)),
      pc.rgbaB(pc.rgba(color2.red, color2.green, color2.blue, 255))

    -- Determine target and mask colors
    if c1_R == c2_R and c1_G == c2_G and c1_B == c2_B then
      -- When Color 1 == Color 2
      if invert then
        -- Draw on non-Color 1 pixels (adjacent mask color corners)
        target_R, target_G, target_B = nil, nil, nil -- Will check non-Color 1 in isDrawSurfaceColor
        mask_R, mask_G, mask_B = c1_R, c1_G, c1_B
      else
        -- Draw on Color 1 pixels
        target_R, target_G, target_B = c1_R, c1_G, c1_B
        mask_R, mask_G, mask_B = nil, nil, nil -- Will check non-Color 1 in isMask
      end
    else
      -- When Color 1 ≠ Color 2
      if invert then
        target_R, target_G, target_B = c2_R, c2_G, c2_B
        mask_R, mask_G, mask_B = c1_R, c1_G, c1_B
      else
        target_R, target_G, target_B = c1_R, c1_G, c1_B
        mask_R, mask_G, mask_B = c2_R, c2_G, c2_B
      end
    end

    -- Determine paint color for Auto Blend
    if autoBlend and (c1_R ~= c2_R or c1_G ~= c2_G or c1_B ~= c2_B) then
      local lum1 = luminance(c1_R, c1_G, c1_B)
      local lum2 = luminance(c2_R, c2_G, c2_B)
      if lum1 > lum2 then
        bright_R, bright_G, bright_B = c1_R, c1_G, c1_B
        dark_R, dark_G, dark_B = c2_R, c2_G, c2_B
      else
        bright_R, bright_G, bright_B = c2_R, c2_G, c2_B
        dark_R, dark_G, dark_B = c1_R, c1_G, c1_B
      end
      -- Blend darker to brighter based on autoRatio (0 = darker, 100 = brighter)
      local ratio = autoRatio / 100
      local r = math.floor(dark_R * (1 - ratio) + bright_R * ratio)
      g = math.floor(dark_G * (1 - ratio) + bright_G * ratio)
      b = math.floor(dark_B * (1 - ratio) + bright_B * ratio)
      FGpix_raw = pc.rgba(r, g, b, 255)
    elseif autoBlend then
      -- When Color 1 == Color 2, defer blending to computeImage (per-pixel adjacent color)
      FGpix_raw = nil
    else
      -- Use Blend Color (respect indexed or rgba)
      if cm == ColorMode.INDEXED then
        FGpix_raw = pc.indexed(blendColor.index)
      else
        FGpix_raw = pc.rgba(blendColor.red, blendColor.green, blendColor.blue, 255)
      end
    end
  end

  -- Compare colors by RGB (handles duplicate palette entries)
  local TOL = 0
  local function rgb_equal(px, r, g, b)
    return math.abs(pc.rgbaR(px) - r) <= TOL
       and math.abs(pc.rgbaG(px) - g) <= TOL
       and math.abs(pc.rgbaB(px) - b) <= TOL
  end

  local function inBounds(x, y) return x >= 0 and y >= 0 and x < w and y < h end

  local function isMask(x, y)
    if not inBounds(x, y) then return false end
    local p = originalImage:getPixel(x, y)
    if c1_R == c2_R and c1_G == c2_G and c1_B == c2_B then
      -- When Color 1 == Color 2, mask is Color 1 if invert, else non-Color 1
      if mask_R then
        return pc.rgbaA(p) == 255 and rgb_equal(p, mask_R, mask_G, mask_B)
      else
        return pc.rgbaA(p) == 255 and not rgb_equal(p, c1_R, c1_G, c1_B)
      end
    else
      return pc.rgbaA(p) == 255 and rgb_equal(p, mask_R, mask_G, mask_B)
    end
  end

  local function isDrawSurfaceColor(x, y)
    if not inBounds(x, y) then return false end
    local p = originalImage:getPixel(x, y)
    if c1_R == c2_R and c1_G == c2_G and c1_B == c2_B and target_R == nil then
      -- When Color 1 == Color 2 and invert, draw on non-Color 1 pixels
      return pc.rgbaA(p) == 255 and not rgb_equal(p, c1_R, c1_G, c1_B)
    else
      return pc.rgbaA(p) == 255 and rgb_equal(p, target_R, target_G, target_B)
    end
  end

  local function inSelXY(x, y)
    if processAll then return true end
    return sel:contains(pos.x + x, pos.y + y)
  end

  -- Mask sides around a pixel (N,E,S,W)
  local function maskSides(x, y)
    return isMask(x, y-1), isMask(x+1, y), isMask(x, y+1), isMask(x-1, y)
  end

  -- Check for isolated corner (Draw surface pixel with >= 3 orthogonal Mask neighbors)
  local function isIsolatedCorner(x, y)
    if not isDrawSurfaceColor(x, y) then return false end
    local n, e, s, w = maskSides(x, y)
    local maskCount = 0
    if n then maskCount = maskCount + 1 end
    if e then maskCount = maskCount + 1 end
    if s then maskCount = maskCount + 1 end
    if w then maskCount = maskCount + 1 end
    return maskCount >= 3
  end

  -- Corner classification for stair-step arms (Draw surface pixel with exactly 2 orthogonal Mask neighbors)
  local function cornerKind(x, y)
    if not isDrawSurfaceColor(x, y) then return false end
    local n, e, s, w = maskSides(x, y)
    if n and e and not s and not w then return "NE"
    elseif e and s and not n and not w then return "SE"
    elseif s and w and not n and not e then return "SW"
    elseif w and n and not e and not s then return "NW"
    else return false end
  end

  local function hasMaskOnSide(x, y, side)
    if side == 'N' then return isMask(x, y-1)
    elseif side == 'E' then return isMask(x+1, y)
    elseif side == 'S' then return isMask(x, y+1)
    else return isMask(x-1, y) end -- 'W'
  end

  -- Get the adjacent mask color for blending
  local function getAdjacentMaskColor(x, y)
    local directions = {{0, -1, 'N'}, {1, 0, 'E'}, {0, 1, 'S'}, {-1, 0, 'W'}}
    for _, dir in ipairs(directions) do
      local dx, dy = dir[1], dir[2]
      if isMask(x + dx, y + dy) then
        local p = originalImage:getPixel(x + dx, y + dy)
        return pc.rgbaR(p), pc.rgbaG(p), pc.rgbaB(p)
      end
    end
    -- Fallback to Color 2 if no adjacent mask color is found
    return c2_R, c2_G, c2_B
  end

  -- Collect the arm (pixels including the starting corner) toward the next corner.
  -- REQUIRE Mask-on-side from the first pixel; EXCLUDE the destination corner.
  local function collect_arm_run(x0, y0, dx, dy, keepSide)
    local run = {{x = x0, y = y0}} -- Start with the corner pixel
    local x, y = x0 + dx, y0 + dy
    while inBounds(x, y) and isDrawSurfaceColor(x, y) do
      -- Stop BEFORE the next corner
      if cornerKind(x, y) then break end
      -- Must hug Mask on the kept side
      if not hasMaskOnSide(x, y, keepSide) then break end
      table.insert(run, {x = x, y = y})
      x, y = x + dx, y + dy
    end
    return run, x, y -- Return the run and the coordinates of the next pixel (possible corner)
  end

  -- Two outgoing arms per corner
  local function armsFor(kind)
    if kind == "NE" then
      return { {dx = -1, dy = 0, keep = 'N'}, {dx = 0, dy = 1, keep = 'E'} }
    elseif kind == "SE" then
      return { {dx = -1, dy = 0, keep = 'S'}, {dx = 0, dy = -1, keep = 'E'} }
    elseif kind == "SW" then
      return { {dx = 1, dy = 0, keep = 'S'}, {dx = 0, dy = -1, keep = 'W'} }
    else -- "NW"
      return { {dx = 1, dy = 0, keep = 'N'}, {dx = 0, dy = 1, keep = 'W'} }
    end
  end

  -- Compute the image based on the percentage, ignoreCorners, autoBlend, autoRatio, and saturation
  local function computeImage(percentage, ignoreCorners, autoBlend, autoRatio, saturation)
    -- Check if the sprite is still valid
    if not app.activeSprite or app.activeSprite ~= spr then
      app.alert("Error: Active sprite has changed. Please re-run the script.")
      return false, nil
    end

    local out = originalImage:clone() -- Use the stored image copy
    local ratio = autoRatio / 100
    for y0 = 0, h-1 do
      for x0 = 0, w-1 do
        -- Check for isolated corner (>= 3 Mask neighbors)
        if isIsolatedCorner(x0, y0) and inSelXY(x0, y0) then
          local r, g, b
          if autoBlend and c1_R == c2_R and c1_G == c2_G and c1_B == c2_B then
            local draw_R, draw_G, draw_B = pc.rgbaR(originalImage:getPixel(x0, y0)), pc.rgbaG(originalImage:getPixel(x0, y0)), pc.rgbaB(originalImage:getPixel(x0, y0))
            local mask_R, mask_G, mask_B = getAdjacentMaskColor(x0, y0)
            local lum_draw = luminance(draw_R, draw_G, draw_B)
            local lum_mask = luminance(mask_R, mask_G, mask_B)
            local dark_r, dark_g, dark_b, bright_r, bright_g, bright_b
            if lum_mask < lum_draw then
              -- Mask color is darker
              dark_r, dark_g, dark_b = mask_R, mask_G, mask_B
              bright_r, bright_g, bright_b = draw_R, draw_G, draw_B
            else
              -- Draw color is darker
              dark_r, dark_g, dark_b = draw_R, draw_G, draw_B
              bright_r, bright_g, bright_b = mask_R, mask_G, mask_B
            end
            r = math.floor(dark_r * (1 - ratio) + bright_r * ratio)
            g = math.floor(dark_g * (1 - ratio) + bright_g * ratio)
            b = math.floor(dark_b * (1 - ratio) + bright_b * ratio)
          elseif autoBlend then
            r = math.floor(dark_R * (1 - ratio) + bright_R * ratio)
            g = math.floor(dark_G * (1 - ratio) + bright_G * ratio)
            b = math.floor(dark_B * (1 - ratio) + bright_B * ratio)
          else
            r, g, b = pc.rgbaR(FGpix_raw), pc.rgbaG(FGpix_raw), pc.rgbaB(FGpix_raw)
          end
          -- Apply saturation after blending
          r, g, b = adjustSaturation(r, g, b, saturation)
          local pixelColor = pc.rgba(r, g, b, 255)
          out:putPixel(x0, y0, pixelColor)
        end

        -- Process stair-step arms
        local kind = cornerKind(x0, y0)
        if kind then
          for _, arm in ipairs(armsFor(kind)) do
            local run, next_x, next_y = collect_arm_run(x0, y0, arm.dx, arm.dy, arm.keep)
            local L = #run
            if L > 0 then
              -- Skip 1-pixel arms if ignoreCorners is true
              if ignoreCorners and L == 1 and not (inBounds(next_x, next_y) and cornerKind(next_x, next_y)) then
                goto continue
              end
              -- Calculate total arm length including the ending corner (if it exists)
              local totalLength = L
              local isEndCorner = inBounds(next_x, next_y) and cornerKind(next_x, next_y)
              if isEndCorner then totalLength = L + 1 end

              -- Determine number of pixels to paint from the start
              local toPaintStart
              if isEndCorner then
                toPaintStart = percentage == 0 and 1 or math.max(1, math.ceil(percentage * totalLength / 100))
              else
                toPaintStart = percentage == 0 and 1 or math.max(1, math.ceil(percentage * L / 100))
              end

              -- Paint from the start (including the starting corner)
              for i = 1, math.min(toPaintStart, L) do
                local p = run[i]
                if inSelXY(p.x, p.y) and isDrawSurfaceColor(p.x, p.y) then
                  local r, g, b
                  if autoBlend and c1_R == c2_R and c1_G == c2_G and c1_B == c2_B then
                    local draw_R, draw_G, draw_B = pc.rgbaR(originalImage:getPixel(p.x, p.y)), pc.rgbaG(originalImage:getPixel(p.x, p.y)), pc.rgbaB(originalImage:getPixel(p.x, p.y))
                    local mask_R, mask_G, mask_B = getAdjacentMaskColor(p.x, p.y)
                    local lum_draw = luminance(draw_R, draw_G, draw_B)
                    local lum_mask = luminance(mask_R, mask_G, mask_B)
                    local dark_r, dark_g, dark_b, bright_r, bright_g, bright_b
                    if lum_mask < lum_draw then
                      -- Mask color is darker
                      dark_r, dark_g, dark_b = mask_R, mask_G, mask_B
                      bright_r, bright_g, bright_b = draw_R, draw_G, draw_B
                    else
                      -- Draw color is darker
                      dark_r, dark_g, dark_b = draw_R, draw_G, draw_B
                      bright_r, bright_g, bright_b = mask_R, mask_G, mask_B
                    end
                    r = math.floor(dark_r * (1 - ratio) + bright_r * ratio)
                    g = math.floor(dark_g * (1 - ratio) + bright_g * ratio)
                    b = math.floor(dark_b * (1 - ratio) + bright_b * ratio)
                  elseif autoBlend then
                    r = math.floor(dark_R * (1 - ratio) + bright_R * ratio)
                    g = math.floor(dark_G * (1 - ratio) + bright_G * ratio)
                    b = math.floor(dark_B * (1 - ratio) + bright_B * ratio)
                  else
                    r, g, b = pc.rgbaR(FGpix_raw), pc.rgbaG(FGpix_raw), pc.rgbaB(FGpix_raw)
                  end
                  -- Apply saturation after blending
                  r, g, b = adjustSaturation(r, g, b, saturation)
                  local pixelColor = pc.rgba(r, g, b, 255)
                  out:putPixel(p.x, p.y, pixelColor)
                end
              end

              -- Paint the ending corner if it exists and within percentage% limit
              if isEndCorner and toPaintStart > 0 then
                if inSelXY(next_x, next_y) and isDrawSurfaceColor(next_x, next_y) then
                  local pixelsFromEnd = percentage == 0 and 1 or math.ceil(percentage * totalLength / 100)
                  if pixelsFromEnd > 0 then
                    local r, g, b
                    if autoBlend and c1_R == c2_R and c1_G == c2_G and c1_B == c2_B then
                      local draw_R, draw_G, draw_B = pc.rgbaR(originalImage:getPixel(next_x, next_y)), pc.rgbaG(originalImage:getPixel(next_x, next_y)), pc.rgbaB(originalImage:getPixel(next_x, next_y))
                      local mask_R, mask_G, mask_B = getAdjacentMaskColor(next_x, next_y)
                      local lum_draw = luminance(draw_R, draw_G, draw_B)
                      local lum_mask = luminance(mask_R, mask_G, mask_B)
                      local dark_r, dark_g, dark_b, bright_r, bright_g, bright_b
                      if lum_mask < lum_draw then
                        -- Mask color is darker
                        dark_r, dark_g, dark_b = mask_R, mask_G, mask_B
                        bright_r, bright_g, bright_b = draw_R, draw_G, draw_B
                      else
                        -- Draw color is darker
                        dark_r, dark_g, dark_b = draw_R, draw_G, draw_B
                        bright_r, bright_g, bright_b = mask_R, mask_G, mask_B
                      end
                      r = math.floor(dark_r * (1 - ratio) + bright_r * ratio)
                      g = math.floor(dark_g * (1 - ratio) + bright_g * ratio)
                      b = math.floor(dark_b * (1 - ratio) + bright_b * ratio)
                    elseif autoBlend then
                      r = math.floor(dark_R * (1 - ratio) + bright_R * ratio)
                      g = math.floor(dark_G * (1 - ratio) + bright_G * ratio)
                      b = math.floor(dark_B * (1 - ratio) + bright_B * ratio)
                    else
                      r, g, b = pc.rgbaR(FGpix_raw), pc.rgbaG(FGpix_raw), pc.rgbaB(FGpix_raw)
                    end
                    -- Apply saturation after blending
                    r, g, b = adjustSaturation(r, g, b, saturation)
                    local pixelColor = pc.rgba(r, g, b, 255)
                    out:putPixel(next_x, next_y, pixelColor)
                  end
                end
              end
            end
            ::continue::
          end
        end
      end
    end
    return true, out
  end

  -- Single transaction for all changes using a modal dialog
  app.transaction("Soften Corners", function()
    local accepted = false
    local dlg = Dialog("Soften Corners")
    local lastImage = originalImage:clone() -- Store the last computed image
    local isEyedropping = false -- Track eyedropper state

    local function recompute()
      updateColors(
        dlg.data.blendColor or app.fgColor,
        dlg.data.color1 or app.fgColor,
        dlg.data.color2 or app.bgColor,
        dlg.data.invert or false,
        dlg.data.autoBlend or false,
        dlg.data.autoRatio or 50
      )
      local percentage = dlg.data.percentage or 20
      local ignoreCorners = dlg.data.ignoreCorners or false
      local autoBlend = dlg.data.autoBlend or false
      local autoRatio = dlg.data.autoRatio or 50
      local saturation = dlg.data.saturation or 50
      local ok, newImage = computeImage(percentage, ignoreCorners, autoBlend, autoRatio, saturation)
      if ok then
        lastImage = newImage
        if app.activeSprite == spr then
          cel.image = newImage
          app.command.Refresh()
        else
          dlg:close()
        end
      else
        dlg:close()
      end
    end

    local function refreshBlendEnabled()
      dlg:modify{
        id = "blendColor",
        enabled = not (dlg.data.autoBlend or false)
      }
      dlg:modify{
        id = "autoRatio",
        enabled = (dlg.data.autoBlend or false)
      }
    end

    -- Color fields first
    dlg:color{
      id = "color1",
      label = "Color 1:",
      color = app.fgColor,
      onchange = function()
        if not isEyedropping then
          recompute()
        end
      end,
      onmousedown = function()
        isEyedropping = true
      end,
      onmouseup = function()
        isEyedropping = false
        recompute()
      end
    }
    dlg:color{
      id = "color2",
      label = "Color 2:",
      color = app.bgColor,
      onchange = function()
        if not isEyedropping then
          recompute()
        end
      end,
      onmousedown = function()
        isEyedropping = true
      end,
      onmouseup = function()
        isEyedropping = false
        recompute()
      end
    }
    dlg:check{
      id = "invert",
      label = "Invert:",
      selected = false,
      onclick = function() recompute() end
    }
    dlg:check{
      id = "ignoreCorners",
      label = "Ignore Corners:",
      selected = false,
      onclick = function() recompute() end
    }
    dlg:check{
      id = "autoBlend",
      label = "Auto blend:",
      selected = false,
      onclick = function()
        refreshBlendEnabled()
        recompute()
      end
    }
    dlg:color{
      id = "blendColor",
      label = "Blend Color:",
      color = app.fgColor,
      onchange = function()
        if not isEyedropping then
          recompute()
        end
      end,
      onmousedown = function()
        isEyedropping = true
      end,
      onmouseup = function()
        isEyedropping = false
        recompute()
      end
    }
    dlg:newrow{}
    -- Length slider with label to the LEFT
    dlg:slider{
      id = "percentage",
      label = "Length:",
      min = 0, max = 100,
      value = 20,
      width = 200,
      focus = true,
      onchange = function() recompute() end
    }
    dlg:newrow{}
    -- Auto Ratio slider with label to the LEFT
    dlg:slider{
      id = "autoRatio",
      label = "Auto Ratio:",
      min = 0, max = 100,
      value = 50,
      width = 200,
      focus = true,
      onchange = function() recompute() end
    }
    dlg:newrow{}
    -- Saturation slider with label to the LEFT
    dlg:slider{
      id = "saturation",
      label = "Saturation:",
      min = 0, max = 100,
      value = 50,
      width = 200,
      focus = true,
      onchange = function() recompute() end
    }
    dlg:separator{}
    dlg:button{
      id = "ok",
      text = "OK",
      onclick = function() accepted = true; dlg:close() end
    }
    dlg:button{
      id = "cancel",
      text = "Cancel",
      onclick = function() dlg:close() end
    }
    -- Set dialog to accommodate fields and sliders
    dlg:modify{ bounds = Rectangle(0, 0, 400, 240) }

    -- Initial paint with default settings
    updateColors(app.fgColor, app.fgColor, app.bgColor, false, false, 50)
    refreshBlendEnabled()
    do
      local ok, initialImage = computeImage(20, false, false, 50, 50)
      if ok and app.activeSprite == spr then
        lastImage = initialImage
        cel.image = initialImage
        app.command.Refresh()
      end
    end

    -- Modal dialog for Aseprite v1.3.7 compatibility
    dlg:show{ wait = true }

    -- Apply final image or revert on dialog closure
    if accepted then
      if app.activeSprite == spr then
        cel.image = lastImage
        app.command.Refresh()
      end
    else
      if app.activeSprite == spr then
        cel.image = originalImage
        app.command.Refresh()
      end
    end
  end)
end